package com.AshleyDingler.finalproject;

public class TaskManager{
	
	private String task;
	private boolean complete;
	
	public TaskManager(String task) {
		this.task = task;
		this.complete = false;
	}
	public String getTask() {
		return this.task;
	}
	public boolean getComplete() {
		return this.complete;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public void setComplete(boolean complete) {
		this.complete = complete;
	}
	
	@Override 
	public String toString() {
		return this.task + (this.complete? " (COMPLETE)" : "");
	}
	
	
}
