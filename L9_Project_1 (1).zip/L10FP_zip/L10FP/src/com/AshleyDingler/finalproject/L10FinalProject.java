package com.AshleyDingler.finalproject;

import java.util.ArrayList;
import java.util.Scanner;

public class L10FinalProject {
	static Scanner sc;
	static ArrayList<TaskManager> tasks;
	public static void main(String[] args) {
		tasks = new ArrayList<TaskManager>();
		sc = new Scanner(System.in);
		
		boolean running = true;
		
		tasks.add(new TaskManager("Do homework"));
		
		do {
			menu();
			int chooseMenu = readLine();
			switch(chooseMenu) {
			case 1: 
				System.out.println("Name of the task to add: ");
				String tn = sc.nextLine();
				addTask(tn);
				break;
			case 2:
				listTasks();
				System.out.println("Item to remove: ");
				int removeId = readLine();
				removeTask(removeId);
				break;
			case 3:
				listTasks();
				System.out.println("Item to complete: ");
				int completeId = readLine();
				completeTask(completeId);
				break;
			case 4:
				listTasks();
				break;
			case 5:
				running = false;
				break;
			default:
				System.out.println("Unknown menu choice");
			}
			
		} 
		while(running);
	}
	public static void menu() {
		System.out.println("-Task Manager-");
		System.out.println("1. Add a task");
		System.out.println("2. Remove a task");
		System.out.println("3. Mark a task complete");
		System.out.println("4. List the tasks");
		System.out.println("5. Quit");
		
		
		System.out.println("What would you like to do?");
	}
	public static int readLine() {
		int result = sc.nextInt();
		sc.nextLine();
		return result;
	}
	public static void listTasks() {
		System.out.println("-Tasks-");
		for (int i = 0; i < tasks.size(); i++) {
			System.out.println(i+1 + ". " + tasks.get(i).toString());
		}
	}
	public static void completeTask(int id) {
		tasks.get(id-1).setComplete(true);
	}
	public static void removeTask(int id) {
		tasks.remove(id-1);
	}
	public static void addTask(String task) {
		tasks.add(new TaskManager(task));
	}
	
	
}
